package com.manaseva.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout box; TextView title;
 public void onCreate(Bundle b){super.onCreate(b); home();}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(24,20,24,20);return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setOnClickListener(v->category());return b;}
 void base(String h){box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,20,20,20);title=t(h,26);title.setTextColor(Color.rgb(25,118,210));box.addView(title);setContentView(box);}
 void home(){base("మన సేవ");box.addView(t("మీ ప్రాంతంలోని పనివారిని సులభంగా పొందండి",19));String[] a={"⚡ Electrician","🔧 Plumber","🔨 Carpenter","🎨 Painter","🧱 Mason","🔩 Welder","🧹 Cleaning","❓ Other Work"};for(String s:a)box.addView(btn(s));Button h=new Button(this);h.setText("📞 Helpline");h.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("మన సేవ Helpline").setMessage("Helpline number ఇంకా configure చేయాలి.").setPositiveButton("OK",null).show();});box.addView(h);}
 void category(){base("సమీపంలోని పనివారు");box.addView(t("మీ Panchayat / Area ఎంచుకోండి",18));EditText area=new EditText(this);area.setHint("గ్రామం / పంచాయతీ");box.addView(area);String[] w={"Worker 1 — Available","Worker 2 — Available","Worker 3 — Busy"};for(String s:w){Button b=btn(s);b.setOnClickListener(v->request());box.addView(b);}}
 void request(){base("పని Request");EditText d=new EditText(this);d.setHint("పని వివరాలు");d.setMinLines(3);box.addView(d);Button send=new Button(this);send.setText("Request పంపండి");send.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Request Sent").setMessage("మీ request local workerకి పంపబడింది.").setPositiveButton("OK",null).show());box.addView(send);}
}

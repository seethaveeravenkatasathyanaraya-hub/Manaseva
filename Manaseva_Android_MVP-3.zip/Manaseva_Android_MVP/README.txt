ManaSeva Android MVP
Upload this ZIP to the GitHub repository. The GitHub Actions workflow can unzip it and build a debug APK.

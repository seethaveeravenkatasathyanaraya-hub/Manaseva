package com.manaseva.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    final int green = Color.rgb(19,138,75), blue = Color.rgb(20,92,180), dark = Color.rgb(30,45,55);
    String selectedService = "";
    String selectedVillage = "";
    String currentWorker = "";

    final String[] services = {"⚡ Electrician","🚰 Plumber","🔥 Welder","🎨 Painter","🧱 Mason","🪚 Carpenter",
            "🧱 Tile Worker","🚿 Water Tank Cleaner","❄ AC Technician","🔧 Mechanic","🪟 Aluminium / Glass","🧹 Cleaning Worker","🏗 Construction Labour","🛠 General Worker","➕ Other Work"};

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    TextView tv(String text, int size, int color) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setPadding(18,14,18,14); return t;
    }
    Button btn(String text, int color) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false); b.setBackgroundColor(color); return b;
    }
    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        TextView bar = tv("☰   " + title + "                         🔔", 20, Color.WHITE); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(green);
        root.addView(bar, new LinearLayout.LayoutParams(-1,65));
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(14,10,14,20);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void addGap(int h){ Space s=new Space(this); content.addView(s,new LinearLayout.LayoutParams(1,h)); }

    void showHome() {
        base("మన సేవ");
        TextView welcome=tv("మన సేవ\nమీ పనికి మీ దగ్గరలోని వ్యక్తి",27,dark); welcome.setGravity(Gravity.CENTER); content.addView(welcome);
        Spinner village = new Spinner(this);
        String[] villages={"📍 గ్రామం / పంచాయతీ ఎంచుకోండి","Hyderabad","Rangareddy","Medchal","Sangareddy"};
        ArrayAdapter<String> va=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,villages); village.setAdapter(va); content.addView(village);
        village.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){selectedVillage=pos==0?"":villages[pos];}});
        addGap(8); content.addView(tv("మీకు ఏ పని కావాలి?",21,dark));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(3);
        for(String s:services){
            Button b=btn(s,Color.rgb(19,138,75)); b.setTextColor(Color.WHITE);
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=130; p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); p.setMargins(5,5,5,5); grid.addView(b,p);
            b.setOnClickListener(v->{ selectedService=s; showWorkers(); });
        }
        content.addView(grid);
        Button emergency=btn("📞  మన సేవ హెల్ప్‌లైన్",blue); content.addView(emergency,new LinearLayout.LayoutParams(-1,60)); emergency.setOnClickListener(v -> showHelp());
    }

    void showWorkers() {
        base("దగ్గరలోని " + selectedService);
        content.addView(tv("📍 " + (selectedVillage.isEmpty()?"మీ Panchayat":selectedVillage) + " పరిధిలో అందుబాటులో ఉన్నవారు",16,dark));
        String[][] workers={{"రమేష్ కుమార్","4.8 ★","1.2 km","AVAILABLE","9000000001"},{"సురేష్","4.6 ★","2.4 km","AVAILABLE","9000000002"},{"మహేష్","4.3 ★","3.1 km","BUSY","9000000003"}};
        for(String[] w:workers){
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,10,14,10); card.setBackgroundColor(Color.rgb(246,249,247));
            card.addView(tv("👷 "+w[0]+"   "+w[3],18,dark)); card.addView(tv(w[1]+"     📍 "+w[2],15,Color.DKGRAY));
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button request=btn("Request",green); Button call=btn("📞 Call",blue); actions.addView(request,new LinearLayout.LayoutParams(0,58,1)); actions.addView(call,new LinearLayout.LayoutParams(0,58,1)); card.addView(actions);
            content.addView(card,new LinearLayout.LayoutParams(-1,190));
            request.setEnabled(w[3].equals("AVAILABLE")); request.setOnClickListener(v -> showRequest(w[0])); call.setOnClickListener(v -> dial(w[4]));
        }
    }
    void showRequest(String worker) {
        currentWorker=worker; base("పని Request");
        content.addView(tv("సేవ: "+selectedService+"\nWorker: "+worker+"\nప్రాంతం: "+(selectedVillage.isEmpty()?"ఎంచుకోలేదు":selectedVillage),19,dark));
        EditText details=new EditText(this); details.setHint("పని వివరాలు రాయండి"); details.setMinLines(4); details.setGravity(Gravity.TOP); content.addView(details);
        EditText address=new EditText(this); address.setHint("ఇంటి చిరునామా / Landmark"); content.addView(address);
        Button send=btn("🟢 Request పంపండి",green); content.addView(send); send.setOnClickListener(v -> { if(details.getText().toString().trim().isEmpty()){details.setError("పని వివరాలు ఇవ్వండి");return;} showStatus(worker); });
    }
    void showStatus(String worker) {
        base("Request Status"); content.addView(tv("✅ మీ Request పంపబడింది",24,green));
        content.addView(tv("🔧 "+selectedService+"\n👷 "+worker+"\n📍 "+(selectedVillage.isEmpty()?"మీ Panchayat":selectedVillage),18,dark));
        content.addView(tv("1. ✅ Request Sent\n\n2. 🟢 Worker Accepted\n\n3. 🚗 Worker On The Way\n\n4. ⏳ Work In Progress\n\n5. ⭕ Completed",17,dark));
        Button call=btn("📞 Workerకి Call",blue); content.addView(call); call.setOnClickListener(v->dial("9000000001"));
        Button home=btn("🏠 Homeకి తిరిగి వెళ్లండి",green); content.addView(home); home.setOnClickListener(v->showHome());
    }
    void showHelp() {
        base("మన సేవ హెల్ప్‌లైన్"); TextView t=tv("📞 1800-XXX-XXXX\n\nఒకే నంబర్‌కు కాల్ చేయండి.\nమీ గ్రామం / పంచాయతీ వివరాలు తెలుసుకుని సరైన workerకి request పంపే విధంగా ఈ service రూపొందించవచ్చు.",22,dark); t.setGravity(Gravity.CENTER); content.addView(t);
        Button call=btn("📞 నంబర్‌కు Call చేయండి",blue); content.addView(call); call.setOnClickListener(v->dial("18000000000"));
        content.addView(tv("గమనిక: ఇది demo number. నిజమైన helpline number పెట్టే ముందు ఈ codeలో number మార్చాలి.",15,Color.DKGRAY));
        Button h=btn("🏠 Home",green); content.addView(h); h.setOnClickListener(v->showHome());
    }
    void dial(String number){ try{startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+number)));}catch(Exception ignored){} }
}

# Manaseva Android MVP

మన సేవ – local service worker request app prototype.

## Included
- Telugu home screen
- Panchayat/area selector
- Service categories
- Worker availability list
- Request form
- Request status flow
- Worker call via Android dialer
- Helpline call via Android dialer

## Build
Open this folder in Android Studio and use **Build > Build APK(s)**.

Demo phone numbers are placeholders and must be replaced before production use.
